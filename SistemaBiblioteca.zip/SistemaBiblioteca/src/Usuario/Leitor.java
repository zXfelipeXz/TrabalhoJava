package Usuario;
import java.util.ArrayList;
import java.util.List;



public class Leitor {

   
    private String nomeLeitor;
    private String endereco;
    private String dataNasc;
    private String sexo;
    private String cpfLeitor;
    private String email;

   
    public Leitor(String nome, String endereco, String dataNasc, String sexo, String cpf, String email) {
    

        this.nomeLeitor = nome;
        this.endereco = endereco;
        this.dataNasc = dataNasc;
        this.sexo = sexo;
        this.cpfLeitor = cpf;
        this.email = email;
    }

    public String getNome() {
        return nomeLeitor;
    }

    public void setNome(String nome) {
        this.nomeLeitor = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getCpf() {
        return cpfLeitor;
    }

    public void setCpf(String cpf) {
        this.cpfLeitor = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Usuario{" + "nome=" + nomeLeitor + " endereco=" + endereco + " Data de Nascimento ="
                + dataNasc + " sexo =" + sexo + " CPF =" + cpfLeitor + " email =" + email + "}";
    
    }
    
}


