package sistemabiblioteca;
import telas.Home;


public class SistemaBiblioteca {

   public static void main(String[] args) {
        // Cria e exibe a janela
        new Home().setVisible(true);
        
    }
} 
