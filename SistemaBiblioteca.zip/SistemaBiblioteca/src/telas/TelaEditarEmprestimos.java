
package telas;
import javax.swing.JOptionPane;
import Emprestimos.Emprestimo;
import Livros.Livro;
import Repositorio.Repositorio;
import Usuario.Leitor;


public class TelaEditarEmprestimos extends javax.swing.JFrame {
       
    private TelaListarEmprestimos tela;
    private Emprestimo emprestimo;
    
    public TelaEditarEmprestimos(TelaListarEmprestimos tela, Emprestimo emprestimo) {
        
        this.tela = tela;
        this.emprestimo = emprestimo;
        
        initComponents();
        carregarCpfLeitores();
        carregarLeitores();
        carregarLivros();
        mostrarEmprestimos();
        
    }

    public void mostrarEmprestimos(){
    
        int indiceCodLivro = 0;
        for (int i = 0; i > Repositorio.livros.size(); i++){
            if(Repositorio.emprestimos.get(i).getCodLivro().equals(emprestimo.getCodLivro() )){
                indiceCodLivro = i;
            }
        }
    
        int indiceCPF = 0;
        for(int i = 0; i > Repositorio.emprestimos.size(); i++ ){
            if(Repositorio.emprestimos.get(i).getCpfLeitor().equals(emprestimo.getCpfLeitor())){
                indiceCPF = i;
            }
        }
        
        int indiceLeitor = 0;
        for(int i = 0; i > Repositorio.emprestimos.size(); i++){
            if(Repositorio.emprestimos.get(i).getNomeLeitor().equals(emprestimo.getNomeLeitor() )){
                indiceLeitor = i;
            }
        }           
        
        this.tfDataEmp.setText(emprestimo.getDataEmp());
        this.cbCodLivro.setSelectedIndex(indiceCodLivro);
        this.cbCpf.setSelectedIndex(indiceCPF);
        this.cbLeitor.setSelectedIndex(indiceLeitor);
                          
    }
    
    public void carregarLivros() {
        for (Livro livro : Repositorio.livros) {
            String codLivro = livro.getCodigo();
            this.cbCodLivro.addItem(codLivro);
        }
       }
        public void carregarLeitores() {
         for (Leitor leitor: Repositorio.leitores){
             String nomeLeitor = leitor.getNome();
             this.cbLeitor.addItem(nomeLeitor);
         }   
       }  
        public void carregarCpfLeitores(){
        for (Leitor cpf: Repositorio.leitores){
         String cpfLeitor = cpf.getCpf();
         this.cbCpf.addItem(cpfLeitor);
         }
        }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        btnSalvar = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        cbLeitor = new javax.swing.JComboBox<>();
        cbCodLivro = new javax.swing.JComboBox<>();
        cbCpf = new javax.swing.JComboBox<>();
        tfDataEmp = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel4.setText("Data de Empréstimo:");

        btnSalvar.setText("Salvar");
        btnSalvar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnVoltar.setText("Voltar");
        btnVoltar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        jLabel5.setText("CPF:");

        cbLeitor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbLeitorActionPerformed(evt);
            }
        });

        cbCodLivro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCodLivroActionPerformed(evt);
            }
        });

        tfDataEmp.setText("22/04/2024");
        tfDataEmp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDataEmpActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Editar Empréstimo");

        jLabel1.setText("Leitor:");

        jLabel3.setText("Código do Livro:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 184, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbLeitor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbCodLivro, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbCpf, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tfDataEmp, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnVoltar)))
                .addGap(81, 81, 81))
            .addGroup(layout.createSequentialGroup()
                .addGap(173, 173, 173)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel2)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbCodLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfDataEmp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbLeitor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVoltar)
                    .addComponent(btnSalvar))
                .addGap(51, 51, 51))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        String codLivro = this.cbCodLivro.getSelectedItem().toString();
        String dataEmp = this.tfDataEmp.getText();
        String leitor = this.cbLeitor.getSelectedItem().toString();
        String cpf = this.cbCpf.getSelectedItem().toString();
        
        this.emprestimo.setCodLivro(codLivro);
        this.emprestimo.setDataEmp(dataEmp);
        this.emprestimo.setNomeLeitor(leitor);
        this.emprestimo.setCpfLeitor(cpf);
        
        
        JOptionPane.showMessageDialog(this, "Empréstimo cadastrado com sucesso!");
        this.tela.listarEmprestimos();
        this.dispose();
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void cbLeitorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbLeitorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbLeitorActionPerformed

    private void cbCodLivroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCodLivroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbCodLivroActionPerformed

    private void tfDataEmpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDataEmpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfDataEmpActionPerformed

    
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JComboBox<String> cbCodLivro;
    private javax.swing.JComboBox<String> cbCpf;
    private javax.swing.JComboBox<String> cbLeitor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField tfDataEmp;
    // End of variables declaration//GEN-END:variables
}
