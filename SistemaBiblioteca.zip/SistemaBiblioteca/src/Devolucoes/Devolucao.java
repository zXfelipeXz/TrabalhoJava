package Devolucoes;
import java.util.ArrayList;
import java.util.List;

     

public class Devolucao {
   private String dataRetorno;
   private String nomeLeitor;
   private String codLivro;
   private String cpfLeitor;
    
    public Devolucao(String dataRetorno, String nomeLeitor, String codLivro, String cpfLeitor) {
        this.dataRetorno = dataRetorno;
        this.nomeLeitor = nomeLeitor;
        this.codLivro = codLivro;
        this.cpfLeitor = cpfLeitor;
    }
    
    
    public String getNomeLeitor() {
        return nomeLeitor;
    }

    public void setNomeLeitor(String nomeLeitor) {
        this.nomeLeitor = nomeLeitor;
    }

    public String getCodLivro() {
        return codLivro;
    }

    public void setCodLivro(String codLivro) {
        this.codLivro = codLivro;
    }

    public String getCpfLeitor() {
        return cpfLeitor;
    }

    public void setCpfLeitor(String cpfLeitor) {
        this.cpfLeitor = cpfLeitor;
    }
   
    
    public String getDataRetorno() {
        return dataRetorno;
    }

   
    public void setDataRetorno(String dataRetorno) {
        this.dataRetorno = dataRetorno;
    }

    public Devolucao(String dataRetorno) {
        this.dataRetorno = dataRetorno;
        
    }
   
 public class listaDevolucao {
    public static List<Devolucao> devolucoes = new ArrayList<>();
       
    }
 @Override
    public String toString(){
        return "Devolução{" + "Data da Devolução= " + dataRetorno + " Leitor= " + nomeLeitor + " Código= "
                + codLivro + " CPF= " + cpfLeitor + "}";
    }
}
